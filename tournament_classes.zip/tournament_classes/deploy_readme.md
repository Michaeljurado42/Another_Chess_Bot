### Running your code

The elements within the tournament_classes are the test_files to make sure 
you are not calling anything illegally.


If you get an error about tkinter, please run 
```sudo apt-get install python3.5-tk```.


To run the actual game, the command is very similar to what you are used to.

From the tournament_classes repo, run ```python play_game.py random_agent.py random_agent.py ```


When you run it, you should see a cool gui, and the game should complete without any errors. 
If you have an error, you likely called something illegally. 